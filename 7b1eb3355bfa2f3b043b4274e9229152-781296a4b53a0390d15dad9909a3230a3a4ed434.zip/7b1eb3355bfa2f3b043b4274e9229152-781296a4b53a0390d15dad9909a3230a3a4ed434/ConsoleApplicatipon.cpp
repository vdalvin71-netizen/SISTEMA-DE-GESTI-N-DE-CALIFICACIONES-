// Pseudocódigo detallado:
// 1. Pedir al usuario el número de estudiantes (n), validar que sea entero > 0.
// 2. Mostrar encabezado de la tabla con columnas: Estudiante, Nota 1..4, Promedio, Estatus.
// 3. Para i de 1 a n:
//    a. Pedir el nombre del estudiante (cadena), validar no vacío.
//    b. Para j de 1 a 4:
//         - Pedir la nota j como número real, validar entrada.
//         - Guardar la nota en un vector.
//    c. Calcular promedio = suma(notas) / 4.
//    d. Estatus = "Aprobado" si promedio >= 70, sino "Reprobado".
//    e. Imprimir fila formateada con anchura fija y 2 decimales en el promedio.
// 4. Manejar entradas inválidas limpiando el flujo y solicitando de nuevo.
// 5. Terminar con código de salida 0.
//
// Implementación en C++ para reemplazar el código Python inválido en un archivo .cpp.
// Esto soluciona los errores E0077 (declaración sin tipo) y E0153 (expresión const char* usada como objeto).

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <limits>

int main() {
    int n;
    std::cout << "Ingrese el número de estudiantes: ";
    while (!(std::cin >> n) || n <= 0) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Entrada inválida. Ingrese un número entero positivo: ";
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    // Encabezado de la tabla
    std::cout << '\n'
              << std::left << std::setw(20) << "Estudiante"
              << std::setw(8)  << "Nota 1"
              << std::setw(8)  << "Nota 2"
              << std::setw(8)  << "Nota 3"
              << std::setw(8)  << "Nota 4"
              << std::setw(10) << "Promedio"
              << std::setw(10) << "Estatus"
              << '\n';
    std::cout << std::string(80, '-') << '\n';

    for (int i = 0; i < n; ++i) {
        std::string nombre;
        // Leer nombre (permitir espacios)
        do {
            std::cout << "\nIngrese el nombre del estudiante: ";
            std::getline(std::cin, nombre);
            if (nombre.empty()) {
                std::cout << "El nombre no puede estar vacío. Intente de nuevo.\n";
            }
        } while (nombre.empty());

        std::vector<double> notas(4);
        for (int j = 0; j < 4; ++j) {
            double nota;
            std::cout << "Ingrese la nota " << (j + 1) << ": ";
            while (!(std::cin >> nota)) {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "Entrada inválida. Ingrese una nota numérica para la nota " << (j + 1) << ": ";
            }
            notas[j] = nota;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        double suma = notas[0] + notas[1] + notas[2] + notas[3];
        double promedio = suma / 4.0;
        std::string estatus = (promedio >= 70.0) ? "Aprobado" : "Reprobado";

        // Mostrar fila formateada
        std::cout << std::left << std::setw(20) << nombre
                  << std::setw(8)  << notas[0]
                  << std::setw(8)  << notas[1]
                  << std::setw(8)  << notas[2]
                  << std::setw(8)  << notas[3]
                  << std::fixed << std::setprecision(2)
                  << std::setw(10) << promedio
                  << std::setw(10) << estatus
                  << '\n';
    }

